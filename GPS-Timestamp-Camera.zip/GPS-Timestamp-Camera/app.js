// Get video, canvas, and button elements
const video = document.getElementById('video');
const canvas = document.getElementById('canvas');
const captureButton = document.getElementById('capture');
const downloadLink = document.getElementById('downloadLink');
const context = canvas.getContext('2d');

// Access the user's camera
navigator.mediaDevices.getUserMedia({ video: true })
    .then((stream) => {
        video.srcObject = stream;
    })
    .catch((err) => {
        console.error("Error accessing camera: ", err);
    });

// Capture photo and overlay timestamp with GPS location
captureButton.addEventListener('click', () => {
    // Draw the video frame on the canvas
    context.drawImage(video, 0, 0, canvas.width, canvas.height);

    // Get the current time
    const timestamp = new Date().toLocaleString();

    // Get GPS coordinates
    navigator.geolocation.getCurrentPosition((position) => {
        const latitude = position.coords.latitude.toFixed(5);
        const longitude = position.coords.longitude.toFixed(5);

        // Overlay timestamp and GPS on the canvas
        context.font = "20px Arial";
        context.fillStyle = "white";
        context.fillText(`Timestamp: ${timestamp}`, 10, canvas.height - 40);
        context.fillText(`Lat: ${latitude}, Lon: ${longitude}`, 10, canvas.height - 10);

        // Convert canvas to image URL and create a download link
        const imageUrl = canvas.toDataURL('image/png');
        downloadLink.href = imageUrl;
        downloadLink.style.display = 'block';
    }, (err) => {
        console.error("Error getting location: ", err);
    });
});
