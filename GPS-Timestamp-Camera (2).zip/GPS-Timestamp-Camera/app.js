const video = document.getElementById('video');
const canvas = document.getElementById('canvas');
const captureButton = document.getElementById('capture');
const downloadLink = document.getElementById('downloadLink');
const context = canvas.getContext('2d');

navigator.mediaDevices.getUserMedia({ video: true })
    .then((stream) => {
        video.srcObject = stream;
    })
    .catch((err) => {
        console.error("Error accessing camera: ", err);
    });

captureButton.addEventListener('click', () => {
    context.drawImage(video, 0, 0, canvas.width, canvas.height);

    const timestamp = new Date().toLocaleString();

    navigator.geolocation.getCurrentPosition((position) => {
        const latitude = position.coords.latitude.toFixed(5);
        const longitude = position.coords.longitude.toFixed(5);

        context.font = "20px Arial";
        context.fillStyle = "white";
        context.fillText(`Timestamp: ${timestamp}`, 10, canvas.height - 40);
        context.fillText(`Lat: ${latitude}, Lon: ${longitude}`, 10, canvas.height - 10);

        const imageUrl = canvas.toDataURL('image/png');
        downloadLink.href = imageUrl;
        downloadLink.style.display = 'block';
    }, (err) => {
        console.error("Error getting location: ", err);
    });
});
